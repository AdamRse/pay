//Collapsible init
document.addEventListener('DOMContentLoaded', function () {
    M.Collapsible.init(document.querySelectorAll('.collapsible'));
    M.FormSelect.init(document.querySelectorAll('select'));
});